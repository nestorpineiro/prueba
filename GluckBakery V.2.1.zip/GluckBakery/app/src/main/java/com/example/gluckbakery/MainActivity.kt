package com.example.gluckbakery // Revisa que este sea tu nombre de paquete

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 1. Conecta este archivo de lógica con el diseño activity_main.xml
        setContentView(R.layout.activity_main)

        // 2. Buscar y guardar referencias a los componentes de la UI.
        // Usamos findViewById para encontrar cada vista por su 'id' que pusimos en el XML.
        val emailEditText = findViewById<EditText>(R.id.emailEditText)
        val passwordEditText = findViewById<EditText>(R.id.passwordEditText)
        val loginButton = findViewById<Button>(R.id.loginButton)
        val registerTextView = findViewById<TextView>(R.id.registerTextView)

        // 3. Definir qué pasa cuando se hace clic en el botón de "Ingresar".

        loginButton.setOnClickListener {
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()

            // 1. PRIMER FILTRO: Verificamos que ningún campo esté vacío.
            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener // Detiene la ejecución aquí.
            }

            // 2. SEGUNDO FILTRO: Validamos el formato del email.
            val isEmailValid = email.contains("@") && email.contains(".") && email.substringBefore("@").length >= 3
            if (!isEmailValid) {
                Toast.makeText(this, R.string.invalid_email_format, Toast.LENGTH_LONG).show()
                return@setOnClickListener // Detiene la ejecución aquí.
            }

            // 3. SI PASA TODOS LOS FILTROS: Procedemos a verificar las credenciales.
            val sharedPreferences = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
            val savedPassword = sharedPreferences.getString(email, null)

            if (savedPassword != null && savedPassword == password) {
                // Login exitoso
                val username = sharedPreferences.getString("${email}_username", "Usuario")
                val intent = Intent(this, WelcomeActivity::class.java)
                intent.putExtra("EXTRA_USERNAME", username)
                startActivity(intent)
                finish()
            } else {
                // Si las credenciales son incorrectas
                Toast.makeText(this, "Email o contraseña incorrectos", Toast.LENGTH_SHORT).show()
            }
        }

        // 4. Definir qué pasa cuando se hace clic en el texto de "Regístrate aquí".
        registerTextView.setOnClickListener {
            // Creamos un Intent para ir a la pantalla de Registro.
            val intent = Intent(this, RegisterActivity::class.java)
            // Iniciamos la nueva pantalla.
            startActivity(intent)
        }
    }
}