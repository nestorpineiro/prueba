package com.example.gluckbakery // Revisa que este sea tu nombre de paquete

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 1. Conecta este código con el diseño activity_register.xml
        setContentView(R.layout.activity_register)

        // 2. Buscar y guardar referencias a los componentes de la UI.
        val usernameEditText = findViewById<EditText>(R.id.usernameRegisterEditText)
        val emailEditText = findViewById<EditText>(R.id.emailRegisterEditText)
        val passwordEditText = findViewById<EditText>(R.id.passwordRegisterEditText)
        val registerButton = findViewById<Button>(R.id.registerButton)

        // 3. Definir qué pasa cuando se hace clic en el botón de "Registrarse".

        registerButton.setOnClickListener {
            // Obtenemos el texto que el usuario escribió.
            val username = usernameEditText.text.toString()
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()

            // 1. PRIMER FILTRO: Verificamos que ningún campo esté vacío.
            if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener // Detiene la ejecución aquí si un campo está vacío.
            }

            // 2. SEGUNDO FILTRO: Si todos los campos están llenos, validamos el formato del email.
            val isEmailValid = email.contains("@") && email.contains(".") && email.substringBefore("@").length >= 3
            if (!isEmailValid) {
                // Si el formato no es válido, mostramos el nuevo mensaje de error.
                Toast.makeText(this, R.string.invalid_email_format, Toast.LENGTH_LONG).show()
                return@setOnClickListener // Detiene la ejecución aquí.
            }

            // 3. SI PASA TODOS LOS FILTROS: Procedemos a guardar los datos.
            val sharedPreferences = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
            val editor = sharedPreferences.edit()

            editor.putString(email, password)
            editor.putString("${email}_username", username)
            editor.apply()

            Toast.makeText(this, "Usuario registrado con éxito", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}