package com.example.gluckbakery // Revisa que este sea tu nombre de paquete

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.ImageView
import android.widget.PopupWindow
import android.widget.TextView
import android.widget.Toast

class WelcomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 1. Conecta con el NUEVO diseño activity_welcome.xml
        setContentView(R.layout.activity_welcome)

        // 2. Buscar las referencias a los componentes de la nueva UI.
        val welcomeTextView = findViewById<TextView>(R.id.welcomeTextView)
        val menuIcon = findViewById<ImageView>(R.id.menuIcon)

        // 3. RECIBIR y MOSTRAR el nombre de usuario (esta lógica no cambia)
        val username = intent.getStringExtra("EXTRA_USERNAME") ?: "Usuario"
        welcomeTextView.text = "Bienvenido/a $username"

        // 4. Definir qué pasa cuando se hace clic en el ÍCONO DE MENÚ.
        menuIcon.setOnClickListener { anchorView ->
            // Cuando se toca el ícono, llamamos a una función que creará y mostrará el menú.
            showPopupMenu(anchorView)
        }
    }

    /**
     * Esta función se encarga de crear y mostrar nuestro menú emergente (PopupWindow).
     * Recibe la "vista ancla" (anchorView), que es el ícono de menú, para saber dónde mostrarse.
     */
    private fun showPopupMenu(anchorView: android.view.View) {
        // "Inflar" significa convertir nuestro archivo XML (popup_menu_layout) en un objeto de vista real que podemos usar.
        val inflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popupView = inflater.inflate(R.layout.popup_menu_layout, null)

        // Creamos el objeto PopupWindow. Le decimos qué vista mostrar y qué tamaño tendrá.
        // El 'true' al final lo hace "focusable", lo que permite que se cierre al tocar fuera de él.
        val popupWindow = PopupWindow(popupView,
            android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
            android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
            true)

        // Ahora, buscamos la opción "Salir" DENTRO de la vista del popup que acabamos de inflar.
        val logoutOption = popupView.findViewById<TextView>(R.id.menuLogout)

        // Le damos la funcionalidad de cerrar sesión.
        logoutOption.setOnClickListener {
            Toast.makeText(this, "Sesión cerrada", Toast.LENGTH_SHORT).show()

            // La lógica es la misma de antes: volver al MainActivity.
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }

        // Las otras opciones del menú, por ahora, solo cierran el popup.
        val homeOption = popupView.findViewById<TextView>(R.id.menuHome)
        homeOption.setOnClickListener {
            popupWindow.dismiss() // Cierra el menú.
        }
        // ... (podríamos hacer lo mismo para las otras opciones) ...


        // Finalmente, mostramos el menú emergente, anclado justo debajo del ícono que se tocó.
        popupWindow.showAsDropDown(anchorView)
    }
}