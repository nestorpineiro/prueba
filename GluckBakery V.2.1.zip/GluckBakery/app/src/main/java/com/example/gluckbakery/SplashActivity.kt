package com.example.gluckbakery // Revisa que este sea tu nombre de paquete

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Conecta este código con el diseño visual que creamos
        setContentView(R.layout.activity_splash)

        // El tiempo que durará el splash: 5000 milisegundos = 5 segundos
        val splashTimeOut: Long = 5000

        // Este bloque de código se ejecutará pasados los 5 segundos
        Handler(Looper.getMainLooper()).postDelayed({
            // Prepara la orden para ir a la siguiente pantalla (MainActivity)
            val intent = Intent(this, MainActivity::class.java)
            // Ejecuta la orden
            startActivity(intent)
            // Cierra esta pantalla para que no se pueda volver atrás
            finish()
        }, splashTimeOut)
    }
}